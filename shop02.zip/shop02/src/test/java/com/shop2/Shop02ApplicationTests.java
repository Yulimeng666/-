package com.shop2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Shop02ApplicationTests {

    @Test
    void contextLoads() {
    }

}
