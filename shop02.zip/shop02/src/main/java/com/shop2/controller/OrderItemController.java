package com.shop2.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 订单商品明细表 前端控制器
 * </p>
 *
 * @author caojun
 * @since 2025-09-02
 */
@RestController
@RequestMapping("/orderItem")
public class OrderItemController {

}
