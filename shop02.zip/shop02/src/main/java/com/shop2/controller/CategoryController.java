package com.shop2.controller;

import com.shop2.common.Result;
import com.shop2.entity.Category;
import com.shop2.entity.dto.CategoryDTO;


import com.shop2.service.ICategoryService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * <p>
 * 商品分类表 前端控制器
 * </p>
 *
 * @author caojun
 * @since 2025-09-02
 */
@RestController
@RequestMapping("/category")
@RequiredArgsConstructor
public class CategoryController {
    private final ICategoryService categoryService;

    /**
     * 获取分类树
     */
    @GetMapping("/tree")
    public Result<List<CategoryDTO>> getCategoryTree() {
        List<CategoryDTO> categoryTree = categoryService.getCategoryTree();
        return Result.success(categoryTree);
    }

    /**
     * 获取所有一级分类
     */
    @GetMapping("/top")
    public Result<List<Category>> getTopLevelCategories() {
        List<Category> topCategories = categoryService.getTopLevelCategories();
        return Result.success(topCategories);
    }

    /**
     * 根据父ID获取分类列表，本来案例有使用到二级分类，供大家参考
     */
    @GetMapping("/parent/{parentId}")
    public Result<List<Category>> getCategoriesByParentId(@PathVariable Integer parentId) {
        List<Category> categories = categoryService.getCategoriesByParentId(parentId);
        return Result.success(categories);
    }


}
