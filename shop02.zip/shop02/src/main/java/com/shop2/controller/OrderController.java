package com.shop2.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.shop2.common.Result;
import com.shop2.entity.Address;
import com.shop2.entity.Order;
import com.shop2.entity.User;
import com.shop2.entity.dto.OrderCreateRequest;
import com.shop2.entity.dto.OrderDTO;
import com.shop2.service.IAddressService;
import com.shop2.service.IOrderService;
import com.shop2.service.IUserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 * 订单主表 前端控制器
 * </p>
 *
 * @author caojun
 * @since 2025-09-02
 */
@RestController
@RequestMapping("/order")
@RequiredArgsConstructor
public class OrderController {
    private final IOrderService orderService;
    private final IUserService userService;
    private final IAddressService addressService;

    private Long getCurrentUserId() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();
        User user = userService.getOne(new com.baomidou.mybatisplus.core.conditions.query.QueryWrapper<User>()
                .eq("username", username));
        if (user == null) {
            throw new RuntimeException("用户不存在");
        }
        return user.getUserId();
    }
    @PostMapping("/create")
    public Result<OrderDTO> createOrder(@Valid @RequestBody OrderCreateRequest request) {
        try {
            Long userId = getCurrentUserId();
            OrderDTO order = orderService.createOrder(userId, request);
            return Result.success(order);
        } catch (Exception e) {
            return Result.error("创建订单失败: " + e.getMessage());
        }
    }


    @GetMapping("/detail/{orderId}")
    public Result<OrderDTO> getOrderDetail(@PathVariable Long orderId) {
        try {
            Long userId = getCurrentUserId();
            OrderDTO orderDTO = orderService.getOrderDetail(orderId, userId);
            return Result.success(orderDTO);
        } catch (Exception e) {
            return Result.error("获取订单详情失败: " + e.getMessage());
        }
    }

    @GetMapping("/list")
    public Result<Page<OrderDTO>> getOrderList(
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "10") Integer size,
            @RequestParam(required = false) String status) {
        try {
            Long userId = getCurrentUserId();
            Page<Order> pageParam = new Page<>(page, size);
            Page<OrderDTO> orders = orderService.getUserOrders(pageParam, userId, status);
            return Result.success(orders);
        } catch (Exception e) {
            return Result.error("获取订单列表失败: " + e.getMessage());
        }
    }
    @PutMapping("/cancel/{orderId}")
    public Result<Boolean> cancelOrder(@PathVariable Long orderId) {
        try {
            Long userId = getCurrentUserId();
            boolean result = orderService.cancelOrder(orderId, userId);
            return Result.success(result);
        } catch (Exception e) {
            return Result.error("取消订单失败: " + e.getMessage());
        }
    }
    @DeleteMapping("/delete/{orderId}")
    public Result<Boolean> deleteOrder(@PathVariable Long orderId) {
        try {
            Long userId = getCurrentUserId();
            boolean result = orderService.deleteOrder(orderId, userId);
            return Result.success(result);
        } catch (Exception e) {
            return Result.error("删除订单失败: " + e.getMessage());
        }
    }
    @PostMapping("/buyNow")
    public Result<OrderDTO> buyNow(@Valid @RequestBody OrderCreateRequest request) {
        try {
            Long userId = getCurrentUserId();
            // 如果没有提供地址ID，使用默认地址
            if (request.getAddressId() == null) {
                Address defaultAddress = addressService.getDefaultAddress(userId);
                if (defaultAddress == null) {
                    return Result.error("请先设置收货地址");
                }
                request.setAddressId(defaultAddress.getAddressId());
            }
            OrderDTO order = orderService.buyNow(userId, request);
            return Result.success(order);
        } catch (Exception e) {
            return Result.error("立即购买失败：" + e.getMessage());
        }
    }
    @PutMapping("/pay/{orderId}")
    public Result<Boolean> payOrder(@PathVariable Long orderId) {
        try {
            Long userId = getCurrentUserId();
            boolean result = orderService.payOrder(orderId, userId);
            return Result.success(result);
        } catch (Exception e) {
            return Result.error("支付失败：" + e.getMessage());
        }
    }
    @PutMapping("/ship/{orderId}")
    public Result<Boolean> shipOrder(@PathVariable Long orderId) {
        try {
            Long userId = getCurrentUserId();
            boolean result = orderService.shipOrder(orderId, userId);
            return Result.success(result);
        } catch (Exception e) {
            return Result.error("发货失败：" + e.getMessage());
        }
    }
    @PutMapping("/confirmReceipt/{orderId}")
    public Result<Boolean> confirmReceipt(@PathVariable Long orderId) {
        try {
            Long userId = getCurrentUserId();
            boolean result = orderService.confirmReceipt(orderId, userId);
            return Result.success(result);
        } catch (Exception e) {
            return Result.error("确认收货失败：" + e.getMessage());
        }
    }
    @PutMapping("/evaluate/{orderId}")
    public Result<Boolean> evaluateOrder(@PathVariable Long orderId, @RequestParam String evaluation) {
        try {
            Long userId = getCurrentUserId();
            boolean result = orderService.evaluateOrder(orderId, userId, evaluation);
            return Result.success(result);
        } catch (Exception e) {
            return Result.error("评价失败：" + e.getMessage());
        }
    }



}
