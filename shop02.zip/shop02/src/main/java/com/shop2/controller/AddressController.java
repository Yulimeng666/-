package com.shop2.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.shop2.common.Result;
import com.shop2.entity.Address;
import com.shop2.entity.User;
import com.shop2.service.IAddressService;
import com.shop2.service.IUserService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 收货地址表 前端控制器
 * </p>
 *
 * @author caojun
 * @since 2025-09-02
 */
@RestController
@RequestMapping("/address")
@RequiredArgsConstructor
public class AddressController {
    private final IAddressService addressService;
    private final IUserService userService;

    private Long getCurrentUserId() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();
        User user = userService.getOne(new com.baomidou.mybatisplus.core.conditions.query.QueryWrapper<User>()
                .eq("username", username));
        if (user == null) {
            throw new RuntimeException("用户不存在");
        }
        return user.getUserId();
    }
    @GetMapping("/default")
    public Result<Address> getDefaultAddress() {
        try {
            Long userId = getCurrentUserId();
            QueryWrapper<Address> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("user_id", userId)
                    .eq("is_default", true)
                    .last("LIMIT 1");
            Address address = addressService.getOne(queryWrapper);
            if (address == null) {
                // 如果没有默认地址，返回第一个地址
                queryWrapper = new QueryWrapper<>();
                queryWrapper.eq("user_id", userId)
                        .last("LIMIT 1");
                address = addressService.getOne(queryWrapper);
            }
            return Result.success(address);
        } catch (Exception e) {
            return Result.error("获取地址失败：" + e.getMessage());
        }
    }

}
