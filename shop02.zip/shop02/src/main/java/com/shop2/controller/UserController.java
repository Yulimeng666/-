package com.shop2.controller;

import com.shop2.common.Result;
import com.shop2.entity.User;
import com.shop2.common.JwtUtil;
import com.shop2.entity.dto.LoginDTO;
import com.shop2.entity.dto.RegisterDTO;
import com.shop2.service.IUserService;
import lombok.RequiredArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/user")
@RequiredArgsConstructor
public class UserController {
    private final IUserService userService;
    private final JwtUtil jwtUtil;
    @PostMapping("/register")
    public Result<User> register(@Validated @RequestBody RegisterDTO registerDTO){
        User user = userService.register(registerDTO);
        user.setPassword(null);
        return Result.success(user);
    }
    @PostMapping("/login")
    public Result<String> login(@Validated @RequestBody LoginDTO loginDTO) {
        String token = userService.login(loginDTO);
        return Result.success(token);
    }
    @PostMapping("/logout")
    public Result<Void> logout(@RequestHeader("Authorization") String authHeader) {
        String token = authHeader.substring(7); // 去掉"Bearer "前缀
        userService.logout(token);
        return Result.success();
    }

    @GetMapping("/info")
    public Result<User> getCurrentUserInfo(@RequestHeader("Authorization") String authHeader) {
        String token = authHeader.substring(7); // 去掉"Bearer "前缀
        String username = jwtUtil.getUsernameFromToken(token);
        User user = userService.getCurrentUserInfo(username);
        return Result.success(user);
    }
}