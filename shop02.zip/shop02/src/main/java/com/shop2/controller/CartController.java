package com.shop2.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.shop2.common.Result;
import com.shop2.entity.User;
import com.shop2.entity.dto.CartDTO;
import com.shop2.entity.dto.CartRequest;
import com.shop2.service.ICartService;
import com.shop2.service.IUserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;

@RestController
@RequestMapping("/cart")
@RequiredArgsConstructor
public class CartController {
    private final ICartService cartService;
    private final IUserService userService;
    private Long getCurrentUserId() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !authentication.isAuthenticated()) {
            throw new RuntimeException("用户未登录");
        }
        String username = authentication.getName();
        // 根据用户名查询用户ID
        try {
            // 这里需要注入UserService来查询用户ID
            User user = userService.getOne(new QueryWrapper<User>().eq("username", username));
            if (user != null) {
                return user.getUserId();
            } else {
                throw new RuntimeException("用户不存在");
            }
        } catch (Exception e) {
            throw new RuntimeException("获取用户ID失败: " + e.getMessage());
        }
    }
    /**
     * 添加商品到购物车
     */
    @PostMapping("/add")
    public Result<CartDTO> addToCart(@Valid @RequestBody CartRequest request) {
        try {
            Long userId = getCurrentUserId();
            CartDTO cartDTO = cartService.addToCart(userId, request);
            return Result.success(cartDTO);
        } catch (Exception e) {
            return Result.error("添加购物车失败: " + e.getMessage());
        }
    }
    /**
     * 获取购物车列表
     */
    @GetMapping("/list")
    public Result<List<CartDTO>> getCartList() {
        try {
            Long userId = getCurrentUserId();
            List<CartDTO> cartList = cartService.getCartList(userId);
            return Result.success(cartList);
        } catch (Exception e) {
            return Result.error("获取购物车失败: " + e.getMessage());
        }
    }
    /**
     * 更新商品数量
     */
    @PutMapping("/updateQuantity")
    public Result<CartDTO> updateQuantity(@RequestParam Long cartItemId,
                                          @RequestParam Integer quantity) {
        try {
            Long userId = getCurrentUserId();
            CartDTO cartDTO = cartService.updateQuantity(userId, cartItemId, quantity);
            return Result.success(cartDTO);
        } catch (Exception e) {
            return Result.error("更新数量失败: " + e.getMessage());
        }
    }
    /**
     * 删除购物车商品
     */
    @DeleteMapping("/remove/{cartItemId}")
    public Result<Boolean> removeFromCart(@PathVariable Long cartItemId) {
        try {
            Long userId = getCurrentUserId();
            boolean result = cartService.removeFromCart(userId, cartItemId);
            return Result.success(result);
        } catch (Exception e) {
            return Result.error("删除失败: " + e.getMessage());
        }
    }

    /**
     * 清空购物车
     */
    @DeleteMapping("/clear")
    public Result<Boolean> clearCart() {
        try {
            Long userId = getCurrentUserId();
            boolean result = cartService.clearCart(userId);
            return Result.success(result);
        } catch (Exception e) {
            return Result.error("清空购物车失败: " + e.getMessage());
        }
    }

    /**
     * 选中/取消选中商品
     */
    @PutMapping("/toggleSelect")
    public Result<CartDTO> toggleSelect(@RequestParam Long cartItemId,
                                        @RequestParam Boolean isSelected) {
        try {
            Long userId = getCurrentUserId();
            CartDTO cartDTO = cartService.toggleSelect(userId, cartItemId, isSelected);
            return Result.success(cartDTO);
        } catch (Exception e) {
            return Result.error("操作失败: " + e.getMessage());
        }
    }
    /**
     * 获取购物车商品数量
     */
    @GetMapping("/count")
    public Result<Long> getCartCount() {
        try {
            Long userId = getCurrentUserId();
            Long count = cartService.getCartCount(userId);
            return Result.success(count);
        } catch (Exception e) {
            return Result.error("获取数量失败: " + e.getMessage());
        }
    }

    /**
     * 获取选中商品总金额
     */
    @GetMapping("/total")
    public Result<BigDecimal> getSelectedTotal() {
        try {
            Long userId = getCurrentUserId();
            BigDecimal total = cartService.getSelectedTotal(userId);
            return Result.success(total);
        } catch (Exception e) {
            return Result.error("计算总金额失败: " + e.getMessage());
        }
    }
}