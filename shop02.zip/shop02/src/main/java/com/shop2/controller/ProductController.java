package com.shop2.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.shop2.common.Result;
import com.shop2.entity.Product;
import com.shop2.entity.dto.ProductAddRequest;
import com.shop2.entity.dto.ProductDTO;
import com.shop2.entity.dto.ProductQuery;
import com.shop2.entity.dto.ProductUpdateRequest;
import com.shop2.service.IProductService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 * 商品信息表 前端控制器
 * </p>
 *
 * @author caojun
 * @since 2025-09-02
 */
@RestController
@RequestMapping("/product")
@RequiredArgsConstructor
public class ProductController {

    private final IProductService productService;

    /**
     * 添加商品
     */
    @PostMapping("/add")
    public Result<ProductDTO> addProduct(@Valid ProductAddRequest request) {
        try {
            ProductDTO product = productService.addProduct(request);
            return Result.success(product);
        } catch (Exception e) {
            return Result.error("商品添加失败：" + e.getMessage());
        }
    }
    /** 分页查询商品列表 */
    @GetMapping("/list")
    public Result<Page<ProductDTO>> getProductList(ProductQuery query) {
        try {
            Page<Product> page = new Page<>(query.getPage(), query.getSize());
            Page<ProductDTO> productPage = productService.getProductList(page, query);
            return Result.success(productPage);
        } catch (Exception e) {
            return Result.error("获取商品列表失败: " + e.getMessage());
        }
    }
    /** 根据ID获取商品详情 */
    @GetMapping("/detail/{id}")
    public Result<ProductDTO> getProductById(@PathVariable Long id) {
        try {
            ProductDTO product = productService.getProductById(id);
            return Result.success(product);
        } catch (Exception e) {
            return Result.error("获取商品详情失败: " + e.getMessage());
        }
    }
    /** 删除商品 */
    @DeleteMapping("/delete/{id}")
    public Result<Boolean> deleteProduct(@PathVariable Long id) {
        try {
            boolean result = productService.deleteProduct(id);
            return Result.success(result);
        } catch (Exception e) {
            return Result.error("删除商品失败: " + e.getMessage());
        }
    }
    /** 更新商品 */
    @PostMapping("/update")
    public Result<ProductDTO> updateProduct(@Valid ProductUpdateRequest request) {
        try {
            ProductDTO product = productService.updateProduct(request);
            return Result.success(product);
        } catch (Exception e) {
            return Result.error("更新商品失败: " + e.getMessage());
        }
    }
}
