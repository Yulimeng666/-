package com.shop2.entity.dto;

import lombok.Data;


import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Data
public class OrderDTO {
    private Long orderId;
    private String orderSn;
    private Long userId;
    private BigDecimal totalAmount;
    private String status;
    private String remark;
    private LocalDateTime createTime;
    // 收货地址信息
    private AddressDTO address;
    // 订单商品明细
    private List<OrderItemDTO> items;
    @Data
    public static class AddressDTO {
        private String recipientName;
        private String phone;
        private String detailAddress;
    }
    @Data
    public static class OrderItemDTO {
        private String productName;
        private BigDecimal productPrice;
        private Integer quantity;
        private String imageUrl;
    }
}
