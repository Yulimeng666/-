package com.shop2.entity.dto;

import lombok.Data;

@Data
public class ProductQuery {
    private String productName;
    private Integer categoryId;
    private Byte status;
    private Integer page = 1;
    private Integer size = 10;
}
