package com.shop2.entity.dto;

import jakarta.validation.constraints.DecimalMin;

import jakarta.validation.constraints.NotBlank;

import jakarta.validation.constraints.NotNull;
import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

import java.math.BigDecimal;
import java.util.List;
@Data

public class ProductAddRequest {

    @NotBlank(message = "商品名称不能为空")
    private String productName;
    private String description;
    @NotNull(message = "价格不能为空")
    @DecimalMin(value = "0.01", message = "价格必须大于0")
    private BigDecimal price;
    @NotNull(message = "库存不能为空")
    private Integer stock;
    @NotNull(message = "分类不能为空")
    private Integer categoryId;
    @NotNull(message = "状态不能为空")
    private Byte status;
    private MultipartFile mainImage;
    private List<MultipartFile> detailImages;
    private String specifications;
}