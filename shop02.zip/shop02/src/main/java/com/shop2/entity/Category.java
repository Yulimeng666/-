package com.shop2.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

/**
 * <p>
 * 商品分类表
 * </p>
 *
 * @author caojun
 * @since 2025-09-02
 */
@Getter
@Setter
@ToString
@TableName("category")
public class Category implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 分类ID
     */
    @TableId(value = "category_id", type = IdType.AUTO)
    private Integer categoryId;

    /**
     * 分类名称
     */
    @TableField("category_name")
    private String categoryName;

    /**
     * 父分类ID（0表示顶级分类）
     */
    @TableField("parent_id")
    private Integer parentId;

    /**
     * 排序值
     */
    @TableField("sort_order")
    private Short sortOrder;

    @TableField("icon")
    private String icon;

    @TableField("status")
    private Integer status;
}
