package com.shop2.entity.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.util.List;

@Data
public class OrderCreateRequest {
    @NotNull(message = "收货地址不能为空")
    private Long addressId;
    private String remark;
    @NotNull(message = "商品信息不能为空")
    private List<OrderItemRequest> items;

    @Data
    public static class OrderItemRequest {
        @NotNull(message = "商品ID不能为空")
        private Long productId;
        @NotNull(message = "商品数量不能为空")
        private Integer quantity;
        private Long cartItemId; // 如果是购物车下单，记录购物车项ID
    }
}