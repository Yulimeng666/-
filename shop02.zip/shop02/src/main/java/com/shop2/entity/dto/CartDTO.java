package com.shop2.entity.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class CartDTO {
    private Long cartItemId;
    private Long userId;
    private String productName;
    private String imageUrl;
    private BigDecimal price;
    private Integer quantity;
    private Boolean isSelected;
    private LocalDateTime createTime;
    private LocalDateTime updateTime;

    public BigDecimal getSubtotal(){
        if(price == null || quantity == null)
            return BigDecimal.ZERO;
        return price.multiply(BigDecimal.valueOf(quantity));
    }
}