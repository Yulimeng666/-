package com.shop2.entity.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@Data
public class ProductDTO {
    private Long productId;
    private String productName;
    private String description;
    private BigDecimal price;
    private Integer stock;
    private Integer categoryId;
    private String categoryName;
    private Byte status;
    private LocalDateTime createTime;
    private String imageUrl;
    private List<String> detailImages;
    private Map<String, List<String>> specifications;
}