package com.shop2.entity.dto;

import lombok.Data;

import java.util.List;

@Data
public class CategoryDTO {
    private Integer categoryId;
    private String categoryName;
    private Integer parentId;
    private Short sortOrder;
    private String icon;
    private List<CategoryDTO> children;
}
