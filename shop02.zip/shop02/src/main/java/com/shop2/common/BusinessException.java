package com.shop2.common;

public class BusinessException extends RuntimeException {
    public BusinessException(String message) {
        super(message);
    }
}