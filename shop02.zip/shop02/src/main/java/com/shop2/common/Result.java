package com.shop2.common;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Result<T> {
    private Integer code; // 状态码（如 200 代表成功；400 代表失败）
    private String msg; // 提示信息
    private T data; // 响应数据（泛型）

    // 成功响应（带数据）
    public static <T> Result<T> success(T data) {
        return new Result<>(200, "success", data);
    }

    // 成功响应（无数据）
    public static Result<Void> success() {
        return new Result<>(200, "success", null);
    }

    // 错误响应
    public static <T> Result<T> error(String msg) {
        return new Result<>(400, msg, null);
    }
}