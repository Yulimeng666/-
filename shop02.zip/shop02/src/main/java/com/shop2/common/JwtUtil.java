package com.shop2.common;

import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

@Component
public class JwtUtil {
    @Value("${jwt.secret}")
    private String secret;
    @Value("${jwt.expiration:604800}")
    private Long expiration;
    private static final Set<String> tokenBlacklist = Collections.synchronizedSet(new HashSet<>());
    public void invalidateToken(String token) {
        tokenBlacklist.add(token);
    }
    public String generateToken(String username) {
        SecretKey key = getSecretKey();

        return Jwts.builder()
                .subject(username)
                .issuedAt(new Date())
                .expiration(new Date(System.currentTimeMillis() + expiration * 1000))
                .signWith(key)
                .compact();
    }
    public String getUsernameFromToken(String token) {
        SecretKey key = getSecretKey();

        return Jwts.parser()
                .verifyWith(key)
                .build()
                .parseSignedClaims(token)
                .getPayload()
                .getSubject();
    }
    public boolean validateToken(String token) {
        try {
            if (tokenBlacklist.contains(token)) {
                return false;
            }
            SecretKey key = getSecretKey();
            Jwts.parser()
                    .verifyWith(key)
                    .build()
                    .parseSignedClaims(token);
            return true;
        } catch (JwtException | IllegalArgumentException e) {
            return false;
        }
    }
    private SecretKey getSecretKey() {
        if (secret.length() < 32) {
            throw new IllegalArgumentException("JWT密钥长度不足，至少需要32字符");
        }
        return Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));
    }
}