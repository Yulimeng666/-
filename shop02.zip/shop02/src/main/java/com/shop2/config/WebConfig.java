package com.shop2.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

// 在WebMvcConfig.java中添加
@Configuration
public class WebConfig implements WebMvcConfigurer {
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        // 获取项目目录路径
        String projectPath = System.getProperty("user.dir");
        String imagePath = "file:" + projectPath + "/uploads/images/";
        // 映射URL路径到实际文件路径
        registry.addResourceHandler("/uploads/images/**")
                .addResourceLocations(imagePath)
                .setCachePeriod(3600)
                .resourceChain(true);

    }
}
