package com.shop2.config;

import com.shop2.common.JwtUtil;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;

@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {
    private static final Logger logger = LoggerFactory.getLogger(JwtAuthenticationFilter.class);
    private static final String AUTH_HEADER = "Authorization";
    private static final String TOKEN_PREFIX = "Bearer ";
    private final JwtUtil jwtUtil;
    // 不需要认证的路径
    private static final String[] EXCLUDE_PATHS = {
            "/user/login",
            "/user/register",
            "/uploads/images/",
            "/api/uploads/",
            "/product/list",
            "/product/detail",
            "http://localhost:8080/api/uploads/no.jpg"
    };

    public JwtAuthenticationFilter(JwtUtil jwtUtil) {
        this.jwtUtil = jwtUtil;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain)
            throws ServletException, IOException {

        String path = request.getServletPath();
        logger.info("Processing request: {}", path);

        // 检查是否是需要跳过的路径
        if (shouldNotFilter(request)) {
            logger.info("Skipping authentication for path: {}", path);
            filterChain.doFilter(request, response);
            return;
        }

        String authHeader = request.getHeader(AUTH_HEADER);
        logger.info("Authorization header: {}", authHeader);

        if (authHeader == null || !authHeader.startsWith(TOKEN_PREFIX)) {
            logger.warn("No valid Authorization header found");
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            response.getWriter().write("需要认证令牌");
            return;
        }

        String token = authHeader.substring(TOKEN_PREFIX.length());
        logger.info("Extracted token: {}", token);

        try {
            if (jwtUtil.validateToken(token)) {
                String username = jwtUtil.getUsernameFromToken(token);
                logger.info("Valid token for user: {}", username);

                if (username != null && SecurityContextHolder.getContext().getAuthentication() == null) {
                    // 创建认证令牌（无凭证）
                    UsernamePasswordAuthenticationToken authentication =
                            new UsernamePasswordAuthenticationToken(username, null, Collections.emptyList());

                    SecurityContextHolder.getContext().setAuthentication(authentication);
                    logger.info("Authentication set for user: {}", username);
                }
            } else {
                logger.warn("Invalid token: {}", token);
                response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                response.getWriter().write("无效的认证令牌");
                return;
            }
        } catch (Exception e) {
            logger.error("Token validation error", e);
            // 令牌无效
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            response.getWriter().write("无效的认证令牌");
            return;
        }

        logger.info("Request authenticated successfully");
        filterChain.doFilter(request, response);
    }

    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) {
        String path = request.getServletPath();
        String method = request.getMethod();
        // 修改匹配逻辑 ↓↓↓
        return Arrays.stream(EXCLUDE_PATHS).anyMatch(exclude ->
                path.equals(exclude) ||
                        path.startsWith(exclude) ||
                        path.equals("/product/list") || // 明确添加列表路径
                        path.startsWith("/product/list?") || // 处理带参数的请求
                        (method.equals("GET") && path.matches("/product/\\d+")) ||
                        (method.equals("GET") && path.startsWith("/product/detail/"))
        );
    }
}
