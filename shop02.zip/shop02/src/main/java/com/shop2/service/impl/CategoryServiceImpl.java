package com.shop2.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.shop2.entity.Category;
import com.shop2.entity.dto.CategoryDTO;
import com.shop2.mapper.CategoryMapper;
import com.shop2.service.ICategoryService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * <p>
 * 商品分类表 服务实现类
 * </p>
 *
 * @author caojun
 * @since 2025-09-02
 */
@Service
@RequiredArgsConstructor
public class CategoryServiceImpl extends ServiceImpl<CategoryMapper, Category> implements ICategoryService {
    private final CategoryMapper categoryMapper;

    @Override
    public List<CategoryDTO> getCategoryTree() {
        // 获取所有启用的分类
        List<Category> allCategories = categoryMapper.selectAllEnabled();
        // 构建树形结构
        return buildCategoryTree(allCategories, 0);
    }

    @Override
    public List<Category> getCategoriesByParentId(Integer parentId) {
        QueryWrapper<Category> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("parent_id", parentId)
                .eq("status", 1)
                .orderByAsc("sort_order");
        return categoryMapper.selectList(queryWrapper);
    }

    @Override
    public List<Category> getTopLevelCategories() {
        return getCategoriesByParentId(0);
    }
    // 递归构建分类树
    private List<CategoryDTO> buildCategoryTree(List<Category> categories, Integer parentId) {
        List<CategoryDTO> result = new ArrayList<>();
        // 获取当前层级的分类
        List<Category> currentLevel = categories.stream()
                .filter(c -> c.getParentId().equals(parentId))
                .collect(Collectors.toList());
        // 递归处理子分类
        for (Category category : currentLevel) {
            CategoryDTO dto = convertToDTO(category);
            dto.setChildren(buildCategoryTree(categories, category.getCategoryId()));
            result.add(dto);
        }
        return result;
    }
    /**
     * 把Category实体转换为CategoryDTO
     */
    private CategoryDTO convertToDTO(Category category) {
        CategoryDTO dto = new CategoryDTO();
        dto.setCategoryId(category.getCategoryId());
        dto.setCategoryName(category.getCategoryName());
        dto.setParentId(category.getParentId());
        dto.setSortOrder(category.getSortOrder());
        dto.setIcon(category.getIcon());
        return dto;
    }

}
