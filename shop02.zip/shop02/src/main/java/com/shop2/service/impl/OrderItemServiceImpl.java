package com.shop2.service.impl;

import com.shop2.entity.OrderItem;
import com.shop2.mapper.OrderItemMapper;
import com.shop2.service.IOrderItemService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 订单商品明细表 服务实现类
 * </p>
 *
 * @author caojun
 * @since 2025-09-02
 */
@Service
public class OrderItemServiceImpl extends ServiceImpl<OrderItemMapper, OrderItem> implements IOrderItemService {

}
