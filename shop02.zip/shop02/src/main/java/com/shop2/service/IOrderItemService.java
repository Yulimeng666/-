package com.shop2.service;

import com.shop2.entity.OrderItem;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 订单商品明细表 服务类
 * </p>
 *
 * @author caojun
 * @since 2025-09-02
 */
public interface IOrderItemService extends IService<OrderItem> {

}
