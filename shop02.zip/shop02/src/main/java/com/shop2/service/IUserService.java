package com.shop2.service;

import com.shop2.entity.User;
import com.baomidou.mybatisplus.extension.service.IService;
import com.shop2.entity.dto.LoginDTO;
import com.shop2.entity.dto.RegisterDTO;

/**
 * <p>
 * 用户信息表 服务类
 * </p>
 *
 * @author caojun
 * @since 2025-09-02
 */
public interface IUserService extends IService<User> {
    User register(RegisterDTO registerDTO);
    String login(LoginDTO loginDTO);
    void logout(String token);
    User getCurrentUserInfo(String username);

}
