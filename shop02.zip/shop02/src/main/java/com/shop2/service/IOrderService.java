package com.shop2.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.shop2.entity.Order;
import com.baomidou.mybatisplus.extension.service.IService;
import com.shop2.entity.dto.OrderCreateRequest;
import com.shop2.entity.dto.OrderDTO;

/**
 * <p>
 * 订单主表 服务类
 * </p>
 *
 * @author caojun
 * @since 2025-09-02
 */
public interface IOrderService extends IService<Order> {
    /** 创建订单 */
    OrderDTO createOrder(Long userId, OrderCreateRequest request);
    /** 获取订单详情 */
    OrderDTO getOrderDetail(Long orderId, Long userId);
    /** 获取用户订单列表 */
    Page<OrderDTO> getUserOrders(Page<Order> page, Long userId, String status);
    /** 取消订单 */
    boolean cancelOrder(Long orderId, Long userId);
    /** 删除订单 */
    boolean deleteOrder(Long orderId, Long userId);
    /** 立即购买（不经过购物车） */
    OrderDTO buyNow(Long userId, OrderCreateRequest request);
    /** 支付订单 */
    boolean payOrder(Long orderId, Long userId);
/**
 由于确认收货、评价订单都是先要发货后才能实现，而发货需要关联权限，故
 我们这里只给出实现的逻辑，没有实现到页面上面。
 同学们可以作为一个扩展功能进行开发。*/
    /** 发货 */
    boolean shipOrder(Long orderId, Long userId);
    /** 确认收货 */
    boolean confirmReceipt(Long orderId, Long userId);
    /** 评价订单 */
    boolean evaluateOrder(Long orderId, Long userId, String evaluation);
}