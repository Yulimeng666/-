package com.shop2.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.shop2.entity.Product;
import com.baomidou.mybatisplus.extension.service.IService;
import com.shop2.entity.dto.ProductAddRequest;
import com.shop2.entity.dto.ProductDTO;
import com.shop2.entity.dto.ProductQuery;
import com.shop2.entity.dto.ProductUpdateRequest;

/**
 * <p>
 * 商品信息表 服务类
 * </p>
 *
 * @author caojun
 * @since 2025-09-02
 */
public interface IProductService extends IService<Product> {
    ProductDTO addProduct(ProductAddRequest request);
    Page<ProductDTO> getProductList(Page<Product> page, ProductQuery query);
    /**
     * 根据ID获取商品详情
     */
    ProductDTO getProductById(Long productId);
    boolean deleteProduct(Long productId);
    ProductDTO updateProduct(ProductUpdateRequest request);

    boolean updateStock(Long productId,Integer changeAmount);
}
