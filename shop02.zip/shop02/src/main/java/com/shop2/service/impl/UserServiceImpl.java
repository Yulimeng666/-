package com.shop2.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.shop2.common.BusinessException;
import com.shop2.common.JwtUtil;
import com.shop2.entity.User;
import com.shop2.entity.dto.LoginDTO;
import com.shop2.entity.dto.RegisterDTO;
import com.shop2.mapper.UserMapper;
import com.shop2.service.IUserService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements IUserService {
    private final UserMapper userMapper;
    private final BCryptPasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;
    @Override
    @Transactional
    public User register(RegisterDTO registerDTO) {
        //检查填入信息是否已存在
        checkIfExists("username",registerDTO.getUsername(),"用户名已被注册");
        checkIfExists("phone",registerDTO.getPhone(),"手机号已被注册");
        checkIfExists("email",registerDTO.getEmail(),"邮箱已被注册");
        User user = new User();
        user.setUsername(registerDTO.getUsername());
        user.setPassword(passwordEncoder.encode(registerDTO.getPassword()));
        user.setPhone(registerDTO.getPhone());
        user.setEmail(registerDTO.getEmail());
        user.setAvatar("default-avatar.png");
        user.setCreateTime(LocalDateTime.now());
        //保存用户
        userMapper.insert(user);
        return user;
    }
    private void checkIfExists(String field, String value, String errorMessage) {
        Integer count = Math.toIntExact(userMapper.selectCount(new QueryWrapper<User>().eq(field, value)));
        if (count != null && count > 0) {
            throw new BusinessException(errorMessage);
        }
    }
    @Override
    public String login(LoginDTO loginDTO) {
        // 使用 MyBatis-Plus 的 QueryWrapper 查询用户
        QueryWrapper<User> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("username", loginDTO.getUsername());
        // 获取用户（查询一条记录）
        User user = userMapper.selectOne(queryWrapper);
        if (user == null) {
            throw new RuntimeException("用户名或密码错误");
        }
        // 验证密码
        if (!passwordEncoder.matches(loginDTO.getPassword(), user.getPassword())) {
            throw new RuntimeException("用户名或密码错误");
        }
        // 生成JWT令牌
        return jwtUtil.generateToken(user.getUsername());
    }
    @Override
    public void logout(String token) {
        jwtUtil.invalidateToken(token);
    }
    @Override
    public User getCurrentUserInfo(String username) {
        QueryWrapper<User> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("username", username);
        User user = userMapper.selectOne(queryWrapper);

        if (user == null){
            throw new BusinessException("用户不存在");
        }
        user.setPassword(null);
        return user;
    }



}