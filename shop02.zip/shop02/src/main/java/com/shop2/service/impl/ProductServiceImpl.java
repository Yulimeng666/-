package com.shop2.service.impl;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.shop2.common.BusinessException;
import com.shop2.entity.Product;
import com.shop2.entity.dto.ProductAddRequest;
import com.shop2.entity.dto.ProductDTO;
import com.shop2.entity.dto.ProductQuery;
import com.shop2.entity.dto.ProductUpdateRequest;
import com.shop2.mapper.ProductMapper;
import com.shop2.service.ICategoryService;
import com.shop2.service.IProductService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;
 
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ProductServiceImpl extends ServiceImpl<ProductMapper, Product> implements IProductService {

    private final ProductMapper productMapper;
    private final ICategoryService categoryService;
    // 图片存储路径
    private static final String UPLOAD_DIR = "uploads/images/";
    @Override
    @Transactional
    public ProductDTO addProduct(ProductAddRequest request) {
        // 验证分类是否存在
        if (categoryService.getById(request.getCategoryId()) == null) {
            throw new RuntimeException("分类不存在");
        }
        // 创建商品实体
        Product product = new Product();
        // 复制基本属性
        product.setProductName(request.getProductName());
        product.setDescription(request.getDescription());
        product.setPrice(request.getPrice());
        product.setStock(request.getStock());
        product.setCategoryId(request.getCategoryId());
        product.setStatus(request.getStatus());
        product.setCreateTime(LocalDateTime.now());
        // 处理主图上传
        if (request.getMainImage() != null && !request.getMainImage().isEmpty()) {
            String mainImagePath = saveImage(request.getMainImage());
            product.setImageUrl(mainImagePath);
        }
        // 处理详情图片上传
        if (request.getDetailImages() != null && !request.getDetailImages().isEmpty()) {
            List<String> detailImagePaths = new ArrayList<>();
            for (MultipartFile image : request.getDetailImages()) {
                if (!image.isEmpty()) {
                    String imagePath = saveImage(image);
                    detailImagePaths.add(imagePath);
                }
            }
            // 将图片路径列表转换为JSON字符串存储
            product.setDetailImages(JSON.toJSONString(detailImagePaths));
        }
        // 保存规格参数
        if (StringUtils.hasText(request.getSpecifications())) {
            product.setSpecifications(request.getSpecifications());
        }
        // 保存商品
        productMapper.insert(product);
        // 转换为DTO返回
        return convertToDTO(product);
    }
    @Override
    @Transactional
    public ProductDTO updateProduct(ProductUpdateRequest request) {
        // 检查商品是否存在
        Product existingProduct = productMapper.selectById(request.getProductId());
        if (existingProduct == null) {
            throw new RuntimeException("商品不存在");
        }
        // 验证分类是否存在
        if (categoryService.getById(request.getCategoryId()) == null) {
            throw new RuntimeException("分类不存在");
        }
        // 更新商品属性
        existingProduct.setProductName(request.getProductName());
        existingProduct.setDescription(request.getDescription());
        existingProduct.setPrice(request.getPrice());
        existingProduct.setStock(request.getStock());
        existingProduct.setCategoryId(request.getCategoryId());
        existingProduct.setStatus(request.getStatus());
        existingProduct.setUpdateTime(LocalDateTime.now());
        // 处理主图上传
        if (request.getMainImage() != null && !request.getMainImage().isEmpty()) {
            String mainImagePath = saveImage(request.getMainImage());
            existingProduct.setImageUrl(mainImagePath);
        }
        // 处理详情图片上传（如果提供了新详情图）
        if (request.getDetailImages() != null && !request.getDetailImages().isEmpty()) {
            List<String> detailImagePaths = new ArrayList<>();
            for (MultipartFile image : request.getDetailImages()) {
                if (!image.isEmpty()) {
                    String imagePath = saveImage(image);
                    detailImagePaths.add(imagePath);
                }
            }
            // 将新图片路径添加到现有路径中
            // 这里示例为替换所有详情图片
            existingProduct.setDetailImages(JSON.toJSONString(detailImagePaths));
        }
        // 更新规格参数
        if (StringUtils.hasText(request.getSpecifications())) {
            existingProduct.setSpecifications(request.getSpecifications());
        }
        // 更新商品
        productMapper.updateById(existingProduct);
        // 转换为DTO返回
        return convertToDTO(existingProduct);
    }



    @Override
    public Page<ProductDTO> getProductList(Page<Product> page, ProductQuery query) {
        LambdaQueryWrapper<Product> queryWrapper = new LambdaQueryWrapper<>();// 构建查询条件
        if (StringUtils.hasText(query.getProductName())) { //商品名称模糊查询
            queryWrapper.like(Product::getProductName, query.getProductName());}
        if (query.getCategoryId() != null) { //分类ID精确查询
            queryWrapper.eq(Product::getCategoryId, query.getCategoryId()); }
        if (query.getStatus() != null) { //状态精确查询
            queryWrapper.eq(Product::getStatus, query.getStatus());}
        queryWrapper.orderByDesc(Product::getCreateTime); //排序条件
        Page<Product> productPage = productMapper.selectPage(page, queryWrapper);// 执行分页查询
        Page<ProductDTO> dtoPage = new Page<>();// 创建DTO分页对象
        BeanUtils.copyProperties(productPage, dtoPage); // 复制分页信息
        // 转换记录列表为DTO格式
        List<ProductDTO> dtoList = productPage.getRecords().stream()
                .map(this::convertToSimpleDTO) // 使用简化DTO转换，不包含大字段
                .collect(Collectors.toList());
        dtoPage.setRecords(dtoList);
        return dtoPage;}
    // 简化DTO转换（用于列表，不包含大字段）
    private ProductDTO convertToSimpleDTO(Product product) {
        ProductDTO dto = new ProductDTO();
        BeanUtils.copyProperties(product, dto);
        // 设置分类名称
        if (product.getCategoryId() != null) {
            dto.setCategoryName(categoryService.getById(product.getCategoryId()).getCategoryName()); }
        return dto;
    }
    @Override
    public ProductDTO getProductById(Long productId) {
        Product product = productMapper.selectById(productId);
        if (product == null) {
            throw new RuntimeException("商品不存在");
        }
        return convertToDTO(product); // 使用完整DTO转换
    }
    @Override
    public boolean deleteProduct(Long productId) {
        // 检查商品是否存在
        Product product = productMapper.selectById(productId);
        if (product == null) {
            throw new RuntimeException("商品不存在");
        }
        // 删除商品
        int result = productMapper.deleteById(productId);
        return result > 0;
    }



    /**
     * 保存图片文件
     */
    private String saveImage(MultipartFile file) {
        try {
            // 创建上传目录
            File uploadDir = new File(UPLOAD_DIR);
            if (!uploadDir.exists()) {
                uploadDir.mkdirs();
            }

            // 生成唯一文件名
            String originalFilename = file.getOriginalFilename();
            String fileExtension = originalFilename != null ?
                    originalFilename.substring(originalFilename.lastIndexOf(".")) : ".jpg";
            String uniqueFileName = UUID.randomUUID().toString() + fileExtension;
            // 保存文件
            Path filePath = Paths.get(UPLOAD_DIR + uniqueFileName);
            Files.write(filePath, file.getBytes());

            // 返回文件路径（实际项目中应该返回可访问的URL）
            return "/" + UPLOAD_DIR + uniqueFileName;
        } catch (IOException e) {
            throw new RuntimeException("图片上传失败", e);
        }
    }
    /**
     * 将Product实体转换为ProductDTO
     */
    private ProductDTO convertToDTO(Product product) {
        ProductDTO dto = new ProductDTO();
        BeanUtils.copyProperties(product, dto);

        // 设置分类名称
        if (product.getCategoryId() != null) {
            dto.setCategoryName(categoryService.getById(product.getCategoryId()).getCategoryName());
        }

        // 解析详情图片JSON字符串为List<String>
        if (product.getDetailImages() != null && !product.getDetailImages().isEmpty()) {
            try {
                dto.setDetailImages(JSON.parseArray(product.getDetailImages(), String.class));
            } catch (Exception e) {
                dto.setDetailImages(new ArrayList<>());
            }
        } else {
            dto.setDetailImages(new ArrayList<>());
        }

        // 解析规格参数JSON字符串为Map
        if (product.getSpecifications() != null && !product.getSpecifications().isEmpty()) {
            try {
                dto.setSpecifications(JSON.parseObject(product.getSpecifications(), Map.class));
            } catch (Exception e) {
                dto.setSpecifications(new HashMap<>());
            }
        } else {
            dto.setSpecifications(new HashMap<>());
        }

        return dto;
    }
    @Override
    public boolean updateStock(Long productId, Integer changeAmount) {
        Product product = productMapper.selectById(productId);
        if (product == null) {
            throw new BusinessException("商品不存在");
        }
        int newStock = product.getStock() + changeAmount;
        if (newStock < 0) {
            throw new BusinessException("商品库存不足");
        }
        product.setStock(newStock);
        product.setUpdateTime(LocalDateTime.now());
        return productMapper.updateById(product) > 0;
    }


}
