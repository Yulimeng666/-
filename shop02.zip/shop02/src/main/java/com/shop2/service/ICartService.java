package com.shop2.service;

import com.shop2.entity.Cart;
import com.baomidou.mybatisplus.extension.service.IService;
import com.shop2.entity.dto.CartDTO;
import com.shop2.entity.dto.CartRequest;

import java.math.BigDecimal;
import java.util.List;

/**
 * <p>
 * 购物车信息表 服务类
 * </p>
 *
 * @author caojun
 * @since 2025-09-02
 */
public interface ICartService extends IService<Cart> {
    /**
     * 添加商品到购物车
     */
    CartDTO addToCart(Long userId, CartRequest request);
    /**
     * 获取用户购物车列表
     */
    List<CartDTO> getCartList(Long userId);
    /**
     * 更新购物车商品数量
     */
    CartDTO updateQuantity(Long userId, Long cartItemId, Integer quantity);
    /**
     * 删除购物车商品
     */
    boolean removeFromCart(Long userId, Long cartItemId);
    /**
     * 清空购物车
     */
    boolean clearCart(Long userId);
    /**
     * 选中/取消选中商品
     */
    CartDTO toggleSelect(Long userId, Long cartItemId, Boolean isSelected);
    /**
     * 获取购物车商品数量
     */
    Long getCartCount(Long userId);
    /**
     * 获取选中商品的总金额
     */
    BigDecimal getSelectedTotal(Long userId);
}
