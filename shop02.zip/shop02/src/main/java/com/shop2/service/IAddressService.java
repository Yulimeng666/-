package com.shop2.service;

import com.shop2.entity.Address;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 收货地址表 服务类
 * </p>
 *
 * @author caojun
 * @since 2025-09-02
 */
public interface IAddressService extends IService<Address> {
    Address getDefaultAddress(Long userId);

}
