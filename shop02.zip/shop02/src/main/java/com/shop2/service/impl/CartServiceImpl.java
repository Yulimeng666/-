package com.shop2.service.impl;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.shop2.common.BusinessException;
import com.shop2.entity.Cart;
import com.shop2.entity.Product;
import com.shop2.entity.dto.CartDTO;
import com.shop2.entity.dto.CartRequest;
import com.shop2.mapper.CartMapper;
import com.shop2.service.ICartService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.shop2.service.IProductService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

/**
 * <p>
 * 购物车信息表 服务实现类
 * </p >
 *
 * @author caojun
 * @since 2025-09-02
 */
@Service
@RequiredArgsConstructor
public class CartServiceImpl extends ServiceImpl<CartMapper, Cart> implements ICartService {
    //将数据库实体对象(Cart和 Product)转换为前端使用的数据传输对象(CartDTO)
    private CartDTO convertToDTO(Cart cart, Product product) {
        CartDTO dto = new CartDTO();
        BeanUtils.copyProperties(cart, dto);
        if (product != null) {
            dto.setProductName(product.getProductName());
            dto.setImageUrl(product.getImageUrl());
            dto.setPrice(product.getPrice());
        }
        return dto;
    }

    private final IProductService productService;
    @Override
    @Transactional
    public CartDTO addToCart(Long userId, CartRequest request) {
        Product product = productService.getById(request.getProductId());
        if (product == null) {throw new BusinessException("商品不存在");}
        if (product.getStock() <= 0) {throw new BusinessException("商品库存不足");}
        if (request.getQuantity() > product.getStock()) {throw new BusinessException("商品库存不足，当前库存：" + product.getStock());}
        // 检查购物车是否已有该商品
        QueryWrapper<Cart> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("user_id", userId)
                .eq("product_id", request.getProductId());
        Cart existingCart = getOne(queryWrapper);
        if (existingCart != null) {
            // 更新数量
            int newQuantity = existingCart.getQuantity() + request.getQuantity();
            if (newQuantity > product.getStock()) {
                throw new BusinessException("超过商品库存，当前库存：" + product.getStock());
            }
            existingCart.setQuantity(newQuantity);
            existingCart.setUpdateTime(LocalDateTime.now());
            updateById(existingCart);
            return convertToDTO(existingCart, product);
        } else {
            // 新增购物车项
            Cart cart = new Cart();
            cart.setUserId(userId);
            cart.setProductId(request.getProductId());
            cart.setQuantity(request.getQuantity());
            cart.setIsSelected(request.getIsSelected());
            cart.setCreateTime(LocalDateTime.now());
            cart.setUpdateTime(LocalDateTime.now());
            save(cart);
            return convertToDTO(cart, product);
        }
    }

    @Override

    public List<CartDTO> getCartList(Long userId) {
        QueryWrapper<Cart> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("user_id", userId)
                .orderByDesc("create_time");
        List<Cart> cartList = list(queryWrapper);

        return cartList.stream().map(cart -> {
            Product product = productService.getById(cart.getProductId());
            return convertToDTO(cart, product);
        }).collect(Collectors.toList());
    }

    @Override
    @Transactional
    public CartDTO updateQuantity(Long userId, Long cartItemId, Integer quantity) {
        if (quantity <= 0) {
            throw new BusinessException("数量必须大于0");
        }
        Cart cart = getById(cartItemId);
        if (cart == null || !cart.getUserId().equals(userId)) {
            throw new BusinessException("购物车项不存在");
        }
        Product product = productService.getById(cart.getProductId());
        if (quantity > product.getStock()) {
            throw new BusinessException("超过商品库存，当前库存：" + product.getStock());
        }
        cart.setQuantity(quantity);
        cart.setUpdateTime(LocalDateTime.now());
        updateById(cart);
        return convertToDTO(cart, product);
    }

    @Override
    @Transactional
    public boolean removeFromCart(Long userId, Long cartItemId) {
        QueryWrapper<Cart> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("cart_item_id", cartItemId)
                .eq("user_id", userId);
        return remove(queryWrapper);
    }

    @Override
    @Transactional
    public boolean clearCart(Long userId) {
        QueryWrapper<Cart> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("user_id", userId);
        return remove(queryWrapper);
    }

    @Override
    @Transactional
    public CartDTO toggleSelect(Long userId, Long cartItemId, Boolean isSelected) {
        Cart cart = getById(cartItemId);
        if (cart == null || !cart.getUserId().equals(userId)) {
            throw new BusinessException("购物车项不存在");
        }
        cart.setIsSelected(isSelected);
        cart.setUpdateTime(LocalDateTime.now());
        updateById(cart);

        Product product = productService.getById(cart.getProductId());
        return convertToDTO(cart, product);
    }

    @Override
    public Long getCartCount(Long userId) {
        QueryWrapper<Cart> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("user_id", userId);
        return count(queryWrapper);
    }

    @Override
    public BigDecimal getSelectedTotal(Long userId) {
        List<CartDTO> cartList = getCartList(userId);
        return cartList.stream()
                .filter(CartDTO::getIsSelected)
                .map(CartDTO::getSubtotal)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
}