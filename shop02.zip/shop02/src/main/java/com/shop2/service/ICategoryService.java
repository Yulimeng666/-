package com.shop2.service;

import com.shop2.entity.Category;
import com.baomidou.mybatisplus.extension.service.IService;
import com.shop2.entity.dto.CategoryDTO;

import java.util.List;

/**
 * <p>
 * 商品分类表 服务类
 * </p>
 *
 * @author caojun
 * @since 2025-09-02
 */
public interface ICategoryService extends IService<Category> {
    /**
     * 获取所有启用的分类（树形结构）
     */
    List<CategoryDTO> getCategoryTree();
    /**
     * 根据父ID获取分类列表
     */
    List<Category> getCategoriesByParentId(Integer parentId);
    /**
     * 获取所有一级分类
     */
    List<Category> getTopLevelCategories();
}
