package com.shop2.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.shop2.entity.Address;
import com.shop2.mapper.AddressMapper;
import com.shop2.service.IAddressService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 收货地址表 服务实现类
 * </p>
 *
 * @author caojun
 * @since 2025-09-02
 */
@Service
public class AddressServiceImpl extends ServiceImpl<AddressMapper, Address> implements IAddressService {
    @Override
    public Address getDefaultAddress(Long userId) {
        QueryWrapper<Address> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("user_id", userId)
                .eq("is_default", true)
                .last("LIMIT 1");
        return getOne(queryWrapper);
    }

}
