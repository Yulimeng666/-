package com.shop2.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.shop2.common.BusinessException;
import com.shop2.entity.Address;
import com.shop2.entity.Order;
import com.shop2.entity.OrderItem;
import com.shop2.entity.Product;
import com.shop2.entity.dto.OrderCreateRequest;
import com.shop2.entity.dto.OrderDTO;
import com.shop2.mapper.OrderMapper;
import com.shop2.service.*;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * <p>
 * 订单主表 服务实现类
 * </p>
 *
 * @author caojun
 * @since 2025-09-02
 */
@Service
@RequiredArgsConstructor
public class OrderServiceImpl extends ServiceImpl<OrderMapper, Order> implements IOrderService {
    private final OrderMapper orderMapper;
    private final IOrderItemService orderItemService;
    private final IProductService productService;
    private final IAddressService addressService;
    private final ICartService cartService;

    private OrderDTO convertToDTO(Order order, Address address, List<OrderItem> orderItems) {
        OrderDTO dto = new OrderDTO();
        BeanUtils.copyProperties(order, dto);
        // 设置地址信息
        if (address != null) {
            OrderDTO.AddressDTO addressDTO = new OrderDTO.AddressDTO();
            addressDTO.setRecipientName(address.getRecipientName());
            addressDTO.setPhone(address.getPhone());
            addressDTO.setDetailAddress(address.getDetailAddress());
            dto.setAddress(addressDTO);
        }
        // 设置订单项信息
        if (orderItems != null) {
            List<OrderDTO.OrderItemDTO> itemDTOs = orderItems.stream().map(item -> {
                OrderDTO.OrderItemDTO itemDTO = new OrderDTO.OrderItemDTO();
                BeanUtils.copyProperties(item, itemDTO);
                // 获取商品图片
                Product product = productService.getById(item.getProductId());
                if (product != null) {
                    itemDTO.setImageUrl(product.getImageUrl());
                }
                return itemDTO;
            }).collect(Collectors.toList());
            dto.setItems(itemDTOs);
        }
        return dto;
    }
    private String generateOrderSn() {
        return "O" + System.currentTimeMillis() + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
    }

    @Override
    @Transactional
    public OrderDTO createOrder(Long userId, OrderCreateRequest request) {
        // 1. 验证收货地址
        Address address = addressService.getById(request.getAddressId());
        if (address == null || !address.getUserId().equals(userId))
            throw new BusinessException("收货地址不存在");
        // 2. 验证商品并计算总金额
        BigDecimal totalAmount = BigDecimal.ZERO;
        List<OrderItem> orderItems = new ArrayList<>();
        List<Long> cartItemIdsToRemove = new ArrayList<>();
        for (OrderCreateRequest.OrderItemRequest itemRequest : request.getItems()) {
            Product product = productService.getById(itemRequest.getProductId());
            if (product == null) {
                throw new BusinessException("商品不存在: " + itemRequest.getProductId());
            }
            if (product.getStock() < itemRequest.getQuantity()) {
                throw new BusinessException("商品库存不足: " + product.getProductName());
            }
            if (!product.getStatus().equals((byte) 1)) {
                throw new BusinessException("商品已下架: " + product.getProductName());
            }
            // 计算小计
            BigDecimal subtotal = product.getPrice().multiply(BigDecimal.valueOf(itemRequest.getQuantity()));
            totalAmount = totalAmount.add(subtotal);
            // 创建订单项
            OrderItem orderItem = new OrderItem();
            orderItem.setProductId(product.getProductId());
            orderItem.setProductName(product.getProductName());
            orderItem.setProductPrice(product.getPrice());
            orderItem.setQuantity(itemRequest.getQuantity());
            orderItems.add(orderItem);
            // 记录需要删除的购物车项
            if (itemRequest.getCartItemId() != null) {
                cartItemIdsToRemove.add(itemRequest.getCartItemId());
            }
        }
        // 3. 生成订单号
        String orderSn = generateOrderSn();
        // 4. 创建订单
        Order order = new Order();
        order.setOrderSn(orderSn);
        order.setUserId(userId);
        order.setAddressId(request.getAddressId());
        order.setTotalAmount(totalAmount);
        order.setStatus("待付款");
        order.setCreateTime(LocalDateTime.now());
        orderMapper.insert(order);
        // 5. 保存订单项并扣减库存
        for (OrderItem orderItem : orderItems) {
            orderItem.setOrderId(order.getOrderId());
            orderItemService.save(orderItem);
            // 扣减库存
            productService.updateStock(orderItem.getProductId(), -orderItem.getQuantity());
        }
        // 6. 删除购物车中已下单的商品
        if (!cartItemIdsToRemove.isEmpty()) {
            for (Long cartItemId : cartItemIdsToRemove) {
                cartService.removeFromCart(userId, cartItemId);
            }
        }
        return convertToDTO(order, address, orderItems);
    }

    @Override
    public OrderDTO getOrderDetail(Long orderId, Long userId) {
        Order order = orderMapper.selectById(orderId);
        if (order == null || !order.getUserId().equals(userId)) {
            throw new BusinessException("订单不存在");
        }
        Address address = addressService.getById(order.getAddressId());
        LambdaQueryWrapper<OrderItem> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(OrderItem::getOrderId, orderId);
        List<OrderItem> orderItems = orderItemService.list(queryWrapper);
        return convertToDTO(order, address, orderItems);
    }

    @Override
    public Page<OrderDTO> getUserOrders(Page<Order> page, Long userId, String status) {
        LambdaQueryWrapper<Order> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(Order::getUserId, userId);
        // 状态映射：前端状态值 -> 数据库状态值
        if (status != null && !status.isEmpty() && !"all".equals(status)) {
            Map<String, String> statusMap = new HashMap<>();
            statusMap.put("pending", "待付款");
            statusMap.put("delivering", "待收货");
            statusMap.put("completed", "已完成");
            String dbStatus = statusMap.get(status);
            if (dbStatus != null) {
                queryWrapper.eq(Order::getStatus, dbStatus);
            }
        }
        queryWrapper.orderByDesc(Order::getCreateTime);
        Page<Order> orderPage = orderMapper.selectPage(page, queryWrapper);
        Page<OrderDTO> dtoPage = new Page<>();
        BeanUtils.copyProperties(orderPage, dtoPage);
        List<OrderDTO> dtoList = orderPage.getRecords().stream().map(order -> {
            Address address = addressService.getById(order.getAddressId());
            LambdaQueryWrapper<OrderItem> itemQuery = new LambdaQueryWrapper<>();
            itemQuery.eq(OrderItem::getOrderId, order.getOrderId());
            List<OrderItem> orderItems = orderItemService.list(itemQuery);
            return convertToDTO(order, address, orderItems);
        }).collect(Collectors.toList());

        dtoPage.setRecords(dtoList);
        return dtoPage;
    }

    @Override
    @Transactional
    public boolean cancelOrder(Long orderId, Long userId) {
        Order order = orderMapper.selectById(orderId);
        if (order == null || !order.getUserId().equals(userId)) {
            throw new BusinessException("订单不存在");
        }
        if (!"待付款".equals(order.getStatus())) {
            throw new BusinessException("只有待付款订单可以取消");
        }
        // 恢复库存
        LambdaQueryWrapper<OrderItem> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(OrderItem::getOrderId, orderId);
        List<OrderItem> orderItems = orderItemService.list(queryWrapper);
        for (OrderItem item : orderItems) {
            productService.updateStock(item.getProductId(), item.getQuantity());
        }
        // 更新订单状态
        order.setStatus("已取消");
        return orderMapper.updateById(order) > 0;
    }

    @Override
    @Transactional
    public boolean deleteOrder(Long orderId, Long userId) {
        try {
            Order order = orderMapper.selectById(orderId);
            if (order == null || !order.getUserId().equals(userId)) {
                throw new BusinessException("订单不存在");
            }
            // 只有已取消或已完成订单可以删除
            if (!"已取消".equals(order.getStatus()) && !"已完成".equals(order.getStatus())) {
                throw new BusinessException("只能删除已取消或已完成的订单");
            }
            // 先删除关联的订单项
            LambdaQueryWrapper<OrderItem> queryWrapper = new LambdaQueryWrapper<>();
            queryWrapper.eq(OrderItem::getOrderId, orderId);
            boolean removedItems = orderItemService.remove(queryWrapper);
            System.out.println("删除订单项结果: " + removedItems + ", 订单ID: " + orderId);
            // 再删除订单
            boolean removedOrder = orderMapper.deleteById(orderId) > 0;
            System.out.println("删除订单结果: " + removedOrder + ", 订单ID: " + orderId);
            return removedOrder;
        } catch (Exception e) {
            System.err.println("删除订单异常: " + e.getMessage());
            throw new BusinessException("删除订单失败: " + e.getMessage());
        }
    }
    @Override
    @Transactional
    public OrderDTO buyNow(Long userId, OrderCreateRequest request) {
        // 立即购买逻辑与创建订单类似，但不处理购物车
        if (request.getItems() == null || request.getItems().size() != 1) {
            throw new BusinessException("立即购买只能购买一件商品");
        }
        // 清除购物车相关ID
        request.getItems().forEach(item -> item.setCartItemId(null));
        return createOrder(userId, request);
    }

    @Override
    @Transactional
    public boolean payOrder(Long orderId, Long userId) {
        Order order = orderMapper.selectById(orderId);
        if (order == null || !order.getUserId().equals(userId)) {
            throw new BusinessException("订单不存在");
        }
        if (!"待付款".equals(order.getStatus())) {
            throw new BusinessException("订单状态不正确，无法支付");
        }
        // 这里可以集成支付逻辑，暂时模拟支付成功
        order.setStatus("待发货");
        return orderMapper.updateById(order) > 0;
    }
    @Override
    @Transactional
    public boolean shipOrder(Long orderId, Long userId) {
        Order order = orderMapper.selectById(orderId);
        if (order == null || !order.getUserId().equals(userId)) {
            throw new BusinessException("订单不存在");
        }
        if (!"待发货".equals(order.getStatus())) {
            throw new BusinessException("订单状态不正确，无法发货");
        }
        order.setStatus("待收货");
        return orderMapper.updateById(order) > 0;
    }
    @Override
    @Transactional
    public boolean confirmReceipt(Long orderId, Long userId) {
        Order order = orderMapper.selectById(orderId);
        if (order == null || !order.getUserId().equals(userId)) {
            throw new BusinessException("订单不存在");
        }
        if (!"待收货".equals(order.getStatus())) {
            throw new BusinessException("订单状态不正确，无法确认收货");
        }
        order.setStatus("已完成");
        return orderMapper.updateById(order) > 0;
    }
    @Override
    @Transactional
    public boolean evaluateOrder(Long orderId, Long userId, String evaluation) {
        Order order = orderMapper.selectById(orderId);
        if (order == null || !order.getUserId().equals(userId)) {
            throw new BusinessException("订单不存在");
        }
        if (!"已完成".equals(order.getStatus())) {
            throw new BusinessException("订单状态不正确，无法评价");
        }
        // 这里可以保存评价信息到数据库
        // 暂时只更新状态为已评价
        order.setStatus("已评价");
        return orderMapper.updateById(order) > 0;
    }


}
