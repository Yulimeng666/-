package com.shop2.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.shop2.entity.Category;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * <p>
 * 商品分类表 Mapper 接口
 * </p>
 *
 * @author caojun
 * @since 2025-09-02
 */
public interface CategoryMapper extends BaseMapper<Category> {
    @Select("select * from category where status = 1 ORDER BY sort_order ASC")
    List<Category> selectAllEnabled();

}
