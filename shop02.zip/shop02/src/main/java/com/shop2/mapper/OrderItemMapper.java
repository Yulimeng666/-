package com.shop2.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.shop2.entity.OrderItem;

/**
 * <p>
 * 订单商品明细表 Mapper 接口
 * </p>
 *
 * @author caojun
 * @since 2025-09-02
 */
public interface OrderItemMapper extends BaseMapper<OrderItem> {

}
