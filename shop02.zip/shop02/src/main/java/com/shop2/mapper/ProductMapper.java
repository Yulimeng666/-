package com.shop2.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.shop2.entity.Product;

/**
 * <p>
 * 商品信息表 Mapper 接口
 * </p>
 *
 * @author caojun
 * @since 2025-09-02
 */
public interface ProductMapper extends BaseMapper<Product> {

}
