package com.shop2.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.shop2.entity.Address;

/**
 * <p>
 * 收货地址表 Mapper 接口
 * </p>
 *
 * @author caojun
 * @since 2025-09-02
 */
public interface AddressMapper extends BaseMapper<Address> {

}
